select* from usersignup;
use book_rental_system;




CREATE TABLE admin_book(
    sr INT AUTO_INCREMENT PRIMARY KEY,
	image blob not null,
    name VARCHAR(225) NOT NULL,
    genres VARCHAR(225) NOT NULL,
    author VARCHAR(100) NOT NULL,
    rent_amt VARCHAR(50) NOT NULL,
   
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
); 


select* from admin_book;
CREATE TABLE fav(
    sr INT AUTO_INCREMENT PRIMARY KEY,
    image blob not null,
    name VARCHAR(225) NOT NULL,
    genres VARCHAR(225) NOT NULL,
    authour VARCHAR(100) NOT NULL,
    rent_amt VARCHAR(50) NOT NULL,
   
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
); 


select*from fav;

CREATE TABLE cart(
    sr INT AUTO_INCREMENT PRIMARY KEY,

    name VARCHAR(225) NOT NULL,
    genres VARCHAR(225) NOT NULL,
    authour VARCHAR(100) NOT NULL,
    rent_amt VARCHAR(50) NOT NULL,
   
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
); 
select*from usersignup;
CREATE TABLE adminsignup(
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(225) NOT NULL,
    email VARCHAR(225) NOT NULL,
    phone VARCHAR(100) NOT NULL,
    password VARCHAR(50) NOT NULL,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
); 


CREATE table userSignup(
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(225) NOT NULL,
    email VARCHAR(100) NOT NULL,
    phone VARCHAR(100) NOT NULL,
    password VARCHAR(50) NOT NULL,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
); 
select*from usersignup;

CREATE TABLE admin_book(
    sr INT AUTO_INCREMENT PRIMARY KEY,
	image longblob not null,
    name VARCHAR(225) NOT NULL,
    genres VARCHAR(225) NOT NULL,
    author VARCHAR(100) NOT NULL,
    rent_amt VARCHAR(50) NOT NULL,
   
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
); 
select*from admin_book;




