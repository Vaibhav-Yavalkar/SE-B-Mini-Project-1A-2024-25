/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package patmini;

/**
 *
 * @author Varunkumar lysetti
 */
public class usersession {
      public static String loggedInUsername = "Tushar"; // Shared static variableSSSS
}
